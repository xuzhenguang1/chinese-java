// 第22课 列表
// 目标：List 与 ArrayList 的增删改查、排序与遍历。
导入 java.util.ArrayList;
导入 java.util.Collections;
导入 java.util.List;

类 第22课列表 {
    公有 静态 无 main(String[] 参数) {
        List<Integer> 数值 = 新建 ArrayList<>();
        数值.add(5);
        数值.add(2);
        数值.add(9);
        数值.add(2);
        System.out.println("原始列表：" + 数值);
        System.out.println("元素个数：" + 数值.size());
        System.out.println("第一个元素：" + 数值.get(0));

        数值.set(0, 50);
        数值.remove(Integer.valueOf(2));
        System.out.println("修改并删除后：" + 数值);

        Collections.sort(数值);
        System.out.println("升序：" + 数值);

        List<String> 名称 = 新建 ArrayList<>();
        名称.add("小明");
        名称.add("小红");
        名称.add("小刚");
        名称.remove("小红");
        System.out.println("名称列表：" + 名称);
        System.out.println("是否包含小明：" + 名称.contains("小明"));

        整数 合计 = 0;
        对于 (整数 项 : 数值) {
            合计 += 项;
        }
        System.out.println("数值合计：" + 合计);
    }
}
