// 第21课 抛出异常
// 目标：主动 throw 异常，并在方法签名上声明 throws。
// 注意：「抛出」对应 throw；方法签名上的 throws 用「声明抛出」，二者是不同的关键字。
类 第21课抛出异常 {
    静态 双浮点 开方(双浮点 值) {
        若 (值 < 0) {
            抛出 新建 IllegalArgumentException("不能对负数开方：" + 值);
        }
        返回 Math.sqrt(值);
    }

    静态 整数 解析(String 文本) 声明抛出 NumberFormatException {
        若 (文本 == 空 || 文本.isEmpty()) {
            抛出 新建 NumberFormatException("文本为空");
        }
        返回 Integer.parseInt(文本);
    }

    公有 静态 无 main(String[] 参数) {
        尝试 {
            System.out.println("9 的开方：" + 开方(9));
            System.out.println("解析 42：" + 解析("42"));
        } 捕获 (IllegalArgumentException 异常) {
            System.out.println("参数错误：" + 异常.getMessage());
        } 兜底 {
            System.out.println("第一组演示结束");
        }

        尝试 {
            System.out.println("开方 -1：" + 开方(-1));
        } 捕获 (IllegalArgumentException 异常) {
            System.out.println("捕获到：" + 异常.getMessage());
        }

        尝试 {
            System.out.println("解析空串：" + 解析(""));
        } 捕获 (NumberFormatException 异常) {
            System.out.println("捕获到：" + 异常.getMessage());
        }
    }
}
