// 第13课 继承
// 目标：extends 继承父类、super 调用父类构造器与方法。
类 第13课继承 {
    静态 类 动物 {
        String 名字;

        动物(String 名字) {
            这.名字 = 名字;
        }

        无 叫声() {
            System.out.println(名字 + " 发出声音");
        }

        无 介绍() {
            System.out.println("我是一只动物，名叫" + 名字);
        }
    }

    静态 类 猫 继承 动物 {
        猫(String 名字) {
            父(名字);
        }

        @Override
        无 叫声() {
            System.out.println(名字 + " 喵喵叫");
        }
    }

    静态 类 狗 继承 动物 {
        狗(String 名字) {
            父(名字);
        }

        @Override
        无 叫声() {
            父.叫声();
            System.out.println(名字 + " 汪汪叫");
        }
    }

    公有 静态 无 main(String[] 参数) {
        猫 小花 = 新建 猫("小花");
        小花.介绍();
        小花.叫声();

        狗 阿黄 = 新建 狗("阿黄");
        阿黄.叫声();
    }
}
