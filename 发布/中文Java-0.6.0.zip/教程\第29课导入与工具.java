// 第29课 导入与工具
// 目标：使用 import 引入标准库工具类，配合 Math、Collections、Optional。
导入 java.util.ArrayList;
导入 java.util.Collections;
导入 java.util.List;
导入 java.util.Optional;

类 第29课导入与工具 {
    公有 静态 无 main(String[] 参数) {
        System.out.println("绝对值：" + Math.abs(-7));
        System.out.println("最大值：" + Math.max(3, 9));
        System.out.println("最小值：" + Math.min(3, 9));
        System.out.println("平方根：" + Math.sqrt(144));
        System.out.println("2 的 10 次方：" + Math.pow(2, 10));
        System.out.println("圆周率：" + Math.PI);
        System.out.println("随机整数：" + (整数) (Math.random() * 100));

        List<String> 工具 = 新建 ArrayList<>();
        工具.add("Math");
        工具.add("Collections");
        工具.add("Optional");
        Collections.sort(工具);
        System.out.println("已排序：" + 工具);

        Optional<String> 首个 = 工具.stream().findFirst();
        首个.ifPresent(名称 -> System.out.println("首个工具：" + 名称));

        Optional<String> 未命中 = Optional.empty();
        System.out.println("未命中默认：" + 未命中.orElse("没有"));
        System.out.println("是否为空容器：" + 未命中.isEmpty());
    }
}
