// 第23课 映射
// 目标：Map 的存取、遍历、统计与默认值。
导入 java.util.LinkedHashMap;
导入 java.util.Map;

类 第23课映射 {
    公有 静态 无 main(String[] 参数) {
        Map<String, Integer> 库存 = 新建 LinkedHashMap<>();
        库存.put("苹果", 3);
        库存.put("香蕉", 5);
        库存.put("橙子", 2);

        System.out.println("苹果库存：" + 库存.get("苹果"));
        System.out.println("葡萄库存：" + 库存.getOrDefault("葡萄", 0));

        库存.put("苹果", 6);
        库存.remove("橙子");
        System.out.println("增删后：" + 库存);

        整数 总量 = 0;
        对于 (Map.Entry<String, Integer> 条目 : 库存.entrySet()) {
            System.out.println("键：" + 条目.getKey() + "，值：" + 条目.getValue());
            总量 += 条目.getValue();
        }
        System.out.println("库存总量：" + 总量);

        库存.merge("香蕉", 2, Integer::sum);
        System.out.println("合并后香蕉：" + 库存.get("香蕉"));

        System.out.println("是否包含键 苹果：" + 库存.containsKey("苹果"));
    }
}
