// 第06课 当循环
// 目标：while / do-while，以及跳出与继续。
类 第06课当循环 {
    公有 静态 无 main(String[] 参数) {
        整数 计数 = 0;

        当 (计数 < 5) {
            计数++;
        }
        System.out.println("当循环结束，计数 = " + 计数);

        整数 倒计时 = 3;
        做 {
            System.out.println("倒计时 " + 倒计时);
            倒计时--;
        } 当 (倒计时 > 0);

        对于 (整数 i = 1; i <= 10; i++) {
            若 (i == 3) {
                继续;
            }
            若 (i == 8) {
                System.out.println("遇到 8，跳出循环");
                跳出;
            }
            System.out.println("i = " + i);
        }
    }
}
