// 第02课 变量与类型
// 目标：认识八个基本类型与字符串类型，学会声明变量并打印。
类 第02课变量与类型 {
    公有 静态 无 main(String[] 参数) {
        整数 年龄 = 18;
        长整数 世界人口 = 8000000000L;
        短整数 月份 = 12;
        字节 级别 = 3;
        双浮点 身高 = 1.75;
        浮点 体重 = 62.5f;
        字符 首字母 = 'A';
        布尔 已成年 = 真;
        String 姓名 = "小明";

        System.out.println("姓名：" + 姓名);
        System.out.println("年龄：" + 年龄);
        System.out.println("身高：" + 身高);
        System.out.println("体重：" + 体重);
        System.out.println("首字母：" + 首字母);
        System.out.println("已成年：" + 已成年);
        System.out.println("月份：" + 月份 + "，级别：" + 级别);
        System.out.println("世界人口约：" + 世界人口);
    }
}
