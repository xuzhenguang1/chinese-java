// 第28课 命令行参数
// 目标：读取 main 的参数数组，处理缺省值与格式错误。
类 第28课命令行参数 {
    公有 静态 无 main(String[] 参数) {
        若 (参数.length == 0) {
            System.out.println("未提供参数，使用默认值");
            System.out.println("用法：java 第28课命令行参数 <姓名> <年龄>");
            System.out.println("示例：java 第28课命令行参数 小明 18");
        }

        String 姓名 = 参数.length > 0 ? 参数[0] : "访客";
        整数 年龄 = 18;

        若 (参数.length > 1) {
            尝试 {
                年龄 = Integer.parseInt(参数[1]);
            } 捕获 (NumberFormatException 异常) {
                System.out.println("年龄参数不是整数，改用默认值 18");
            }
        }

        System.out.println("你好，" + 姓名 + "，你今年 " + 年龄 + " 岁。");

        若 (年龄 < 18) {
            System.out.println("未成年");
        } 否则 {
            System.out.println("已成年");
        }

        System.out.println("共收到 " + 参数.length + " 个参数");
    }
}
