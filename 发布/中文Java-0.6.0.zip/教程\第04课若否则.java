// 第04课 若否则
// 目标：条件分支、嵌套判断、逻辑运算。
类 第04课若否则 {
    公有 静态 无 main(String[] 参数) {
        整数 分数 = 78;

        若 (分数 >= 90) {
            System.out.println("优秀");
        } 否则 若 (分数 >= 60) {
            System.out.println("及格");
        } 否则 {
            System.out.println("不及格");
        }

        布尔 下雨 = 假;
        布尔 带伞 = 真;

        若 (下雨 && 带伞) {
            System.out.println("下雨但带伞，可以出门");
        } 否则 若 (下雨 || !带伞) {
            System.out.println("需要留意天气");
        } 否则 {
            System.out.println("天气不错");
        }

        String 状态 = 分数 >= 60 ? "通过" : "待补考";
        System.out.println("三目运算结果：" + 状态);
    }
}
