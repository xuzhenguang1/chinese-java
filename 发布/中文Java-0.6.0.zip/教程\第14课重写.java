// 第14课 重写
// 目标：重写父类方法，覆盖 toString 与 equals。
类 第14课重写 {
    静态 类 点 {
        整数 x;
        整数 y;

        点(整数 x, 整数 y) {
            这.x = x;
            这.y = y;
        }

        @Override
        公有 String toString() {
            返回 "点(" + x + ", " + y + ")";
        }

        @Override
        公有 布尔 equals(Object 其它) {
            若 (这 == 其它) {
                返回 真;
            }
            若 (!(其它 是 点)) {
                返回 假;
            }
            点 另一个 = (点) 其它;
            返回 x == 另一个.x && y == 另一个.y;
        }

        @Override
        公有 整数 hashCode() {
            返回 31 * x + y;
        }
    }

    公有 静态 无 main(String[] 参数) {
        点 甲 = 新建 点(3, 4);
        点 乙 = 新建 点(3, 4);
        点 丙 = 新建 点(5, 6);

        System.out.println("甲 = " + 甲);
        System.out.println("甲 equals 乙：" + 甲.equals(乙));
        System.out.println("甲 equals 丙：" + 甲.equals(丙));
        System.out.println("甲 hashCode：" + 甲.hashCode() + "，乙 hashCode：" + 乙.hashCode());
    }
}
