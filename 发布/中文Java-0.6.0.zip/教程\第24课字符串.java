// 第24课 字符串
// 目标：String 常用方法、拆分与拼接、StringBuilder。
类 第24课字符串 {
    公有 静态 无 main(String[] 参数) {
        String 原句 = "  Java 中文编程  ";
        String 修剪后 = 原句.trim();

        System.out.println("原长度：" + 原句.length() + "，修剪后长度：" + 修剪后.length());
        System.out.println("大写：" + 修剪后.toUpperCase());
        System.out.println("包含 Java：" + 修剪后.contains("Java"));
        System.out.println("以 Java 开头：" + 修剪后.startsWith("Java"));
        System.out.println("替换结果：" + 修剪后.replace("Java", "中文 Java"));
        System.out.println("取前四个字符：" + 修剪后.substring(0, 4));

        String[] 片段 = 修剪后.split(" ");
        System.out.println("片段个数：" + 片段.length);
        System.out.println("拼接：" + String.join(" / ", 片段));

        StringBuilder 构建器 = 新建 StringBuilder();
        构建器.append("第").append(24).append("课");
        构建器.append("：").append("字符串处理");
        System.out.println("构建结果：" + 构建器.toString());

        String 复读 = "哈".repeat(3);
        System.out.println("重复三次：" + 复读);
    }
}
