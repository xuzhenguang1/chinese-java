// 第03课 运算与字符串
// 目标：算术运算、整数除法与取余、类型转换、字符串拼接。
类 第03课运算与字符串 {
    公有 静态 无 main(String[] 参数) {
        整数 甲 = 17;
        整数 乙 = 5;

        整数 和 = 甲 + 乙;
        整数 差 = 甲 - 乙;
        整数 积 = 甲 * 乙;
        整数 商 = 甲 / 乙;
        整数 余数 = 甲 % 乙;
        双浮点 精确商 = (双浮点) 甲 / 乙;

        System.out.println("和：" + 和);
        System.out.println("差：" + 差);
        System.out.println("积：" + 积);
        System.out.println("整数除法商：" + 商 + "，余数：" + 余数);
        System.out.println("精确商：" + 精确商);

        String 标题 = "运算演示";
        String 明细 = 标题 + "：" + 甲 + " + " + 乙 + " = " + 和;
        System.out.println(明细);

        和 += 3;
        和--;
        System.out.println("自增自减后：" + 和);
    }
}
