﻿# 中文 javac 启动器：在运行期给 jdk.compiler 打上中文关键字补丁
# 用法： .\中文javac.ps1 -encoding UTF-8 -d 输出 示例\你好世界.java
#        .\中文javac.ps1 @参数文件
# 说明：补丁类目录为 工具\原生补丁\类，需先执行 编译.ps1。

chcp 65001 | Out-Null
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# 版本锁定检查：补丁基于 JDK 25 的 Tokens.java 生成，跨版本可能失效
$javaExe = (Get-Command java).Source
$javaHome = Split-Path (Split-Path $javaExe -Parent) -Parent
$releaseFile = Join-Path $javaHome 'release'
if (Test-Path $releaseFile) {
    $hit = Select-String -Path $releaseFile -Pattern 'JAVA_VERSION="(.+)"' | Select-Object -First 1
    if ($hit -and $hit.Matches[0].Groups[1].Value -notmatch '^25') {
        Write-Warning "补丁基于 JDK 25 生成，当前 JDK 为 $($hit.Matches[0].Groups[1].Value)，请按 方案文档 第 14 节重新生成补丁"
    }
}

$patch = Join-Path $PSScriptRoot '类'
if (-not (Test-Path $patch)) {
    Write-Error "找不到补丁类目录：$patch，请先运行 编译.ps1"
    exit 2
}

java "-Dstdout.encoding=UTF-8" "-Dstderr.encoding=UTF-8" "-Duser.language=zh" "-Duser.country=CN" --patch-module "jdk.compiler=$patch" -m jdk.compiler/com.sun.tools.javac.Main @args
exit $LASTEXITCODE
