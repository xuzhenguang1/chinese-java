// 第20课 捕获异常
// 目标：try / catch / finally 的基本用法，异常不会让程序直接崩溃。
类 第20课捕获异常 {
    静态 整数 除以(整数 甲, 整数 乙) {
        返回 甲 / 乙;
    }

    公有 静态 无 main(String[] 参数) {
        尝试 {
            整数 结果 = 除以(10, 0);
            System.out.println("结果：" + 结果);
        } 捕获 (ArithmeticException 异常) {
            System.out.println("捕获到运算异常：" + 异常.getMessage());
        } 兜底 {
            System.out.println("除法演示结束");
        }

        尝试 {
            String 文本 = 空;
            System.out.println("文本长度：" + 文本.length());
        } 捕获 (NullPointerException 异常) {
            System.out.println("捕获到空指针异常");
        }

        尝试 {
            整数[] 数组 = {1, 2, 3};
            System.out.println("越界访问：" + 数组[5]);
        } 捕获 (ArrayIndexOutOfBoundsException 异常) {
            System.out.println("捕获到数组越界：" + 异常.getMessage());
        }

        System.out.println("程序继续运行");
    }
}
