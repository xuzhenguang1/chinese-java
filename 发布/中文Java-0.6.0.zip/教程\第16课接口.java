// 第16课 接口
// 目标：接口定义行为契约，多个类用 implements 实现它。
类 第16课接口 {
    接口 问候 {
        整数 版本 = 1;

        String 内容();
    }

    接口 计算 {
        双浮点 求值(双浮点 输入);
    }

    静态 类 中文问候 实现 问候 {
        @Override
        公有 String 内容() {
            返回 "你好";
        }
    }

    静态 类 英文问候 实现 问候 {
        @Override
        公有 String 内容() {
            返回 "Hello";
        }
    }

    静态 类 平方器 实现 计算 {
        @Override
        公有 双浮点 求值(双浮点 输入) {
            返回 输入 * 输入;
        }
    }

    公有 静态 无 main(String[] 参数) {
        问候 甲 = 新建 中文问候();
        问候 乙 = 新建 英文问候();
        System.out.println("中文：" + 甲.内容());
        System.out.println("英文：" + 乙.内容());
        System.out.println("接口常量版本：" + 问候.版本);

        计算 平方 = 新建 平方器();
        System.out.println("3 的平方：" + 平方.求值(3));
    }
}
