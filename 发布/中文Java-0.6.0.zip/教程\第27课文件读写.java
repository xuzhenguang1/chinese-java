// 第27课 文件读写
// 目标：用 Files 读写 UTF-8 文本文件；请在仓库根目录运行，文件会写到 构建/教程 下。
导入 java.io.IOException;
导入 java.nio.charset.StandardCharsets;
导入 java.nio.file.Files;
导入 java.nio.file.Path;

类 第27课文件读写 {
    公有 静态 无 main(String[] 参数) {
        Path 目标 = Path.of("构建", "教程", "第27课.txt");

        尝试 {
            Files.createDirectories(目标.getParent());
            Files.writeString(目标, "第一行：中文 Java\n第二行：文件读写\n", StandardCharsets.UTF_8);
            System.out.println("写入成功：" + 目标.toAbsolutePath());

            String 读回 = Files.readString(目标, StandardCharsets.UTF_8);
            System.out.println("读回内容：");
            System.out.print(读回);

            System.out.println("行数：" + Files.readAllLines(目标, StandardCharsets.UTF_8).size());
            System.out.println("文件存在：" + Files.exists(目标));
        } 捕获 (IOException 异常) {
            System.out.println("文件操作失败：" + 异常.getMessage());
        }
    }
}
