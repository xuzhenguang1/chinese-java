// Cjc —— 中文 Java 源码检查、转译与编译工具（M2）
// 目标：把中文关键字与全角标点翻译成等宽英文，交给原生 javac；诊断位置回映射到中文源码。
//
// 用法：
//   java 工具\cjc\Cjc.java 检查 <文件或目录...>
//   java 工具\cjc\Cjc.java 编译 <文件或目录...> -d <输出目录> [-jar <jar路径> -主类 <全限定类名>]
//   java 工具\cjc\Cjc.java 转译 <文件或目录...> -d <输出目录>
//   java 工具\cjc\Cjc.java 反译 <文件或目录...> -d <输出目录>

import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Cjc {

    static final int KIND_KEYWORD = 0;
    static final int KIND_IDENTIFIER = 1;
    static final int KIND_OTHER = 2;
    static final int KIND_PUNCT = 3;      // 已规范化的全角标点（半角化）
    static final int KIND_BAD_PUNCT = 4;  // 无法规范化的 CJK 标点（报 CJK002）

    // 关键字表来自 工具\cjc\关键字表.txt（M1 外置）。只追加、不替换英文关键字，中文与英文可混编；
    // 同一英文关键字可对应多个中文同义词（如 公有/公开/公共/公用）。
    static final LinkedHashMap<String, String> KEYWORDS = new LinkedHashMap<>();
    static final List<String> SORTED_KEYWORDS = new ArrayList<>();

    // 全角标点：U+FF01..U+FF5E 统一平移 0xFEE0 得到半角；U+3000 全角空格转半角空格。
    // javac 不接受全角空格与全角标点，必须在这里规范化。
    // 无法映射到半角的 CJK 标点（顿号、句号、书名号、弯引号等）一律报 CJK002。
    static final Set<Integer> CJK_PUNCTUATION = Set.of(
            0x3001, 0x3002, 0x3005,
            0x3008, 0x3009, 0x300A, 0x300B, 0x300C, 0x300D, 0x300E, 0x300F,
            0x3010, 0x3011, 0x3014, 0x3015, 0x3016, 0x3017, 0x3018, 0x3019,
            0x301A, 0x301B, 0x301C,
            0x2013, 0x2014, 0x2018, 0x2019, 0x201C, 0x201D, 0x2026,
            0x00B7, 0x203B);

    static final int KIND_EN_KEYWORD = 5;  // 反译模式下命中的英文关键字

    // 反译用：英文 → 中文 的反向表，以及英文关键字集合（由关键字表加载时构建）
    static final LinkedHashMap<String, String> CHINESE_BY_ENGLISH = new LinkedHashMap<>();
    static final Set<String> ENGLISH_KEYWORDS = new HashSet<>();

    public static void main(String[] args) throws IOException {
        if (args.length == 0) {
            usage();
            System.exit(2);
        }
        String command = args[0];
        List<String> inputs = new ArrayList<>();
        Path outDir = null;
        Path jarPath = null;
        String mainClass = null;
        String tableArg = null;
        String classpath = null;
        for (int i = 1; i < args.length; i++) {
            if (args[i].equals("-d")) {
                if (i + 1 >= args.length) {
                    System.err.println("错误：-d 后缺少输出目录");
                    System.exit(2);
                }
                outDir = Paths.get(args[++i]);
            } else if (args[i].equals("-jar")) {
                if (i + 1 >= args.length) {
                    System.err.println("错误：-jar 后缺少 jar 路径");
                    System.exit(2);
                }
                jarPath = Paths.get(args[++i]);
            } else if (args[i].equals("-主类")) {
                if (i + 1 >= args.length) {
                    System.err.println("错误：-主类 后缺少全限定类名");
                    System.exit(2);
                }
                mainClass = args[++i];
            } else if (args[i].equals("--表")) {
                if (i + 1 >= args.length) {
                    System.err.println("错误：--表 后缺少关键字表路径");
                    System.exit(2);
                }
                tableArg = args[++i];
            } else if (args[i].equals("-cp") || args[i].equals("--类路径")) {
                if (i + 1 >= args.length) {
                    System.err.println("错误：" + args[i] + " 后缺少类路径");
                    System.exit(2);
                }
                classpath = args[++i];
            } else {
                inputs.add(args[i]);
            }
        }
        boolean knownCommand = command.equals("检查") || command.equals("编译")
                || command.equals("转译") || command.equals("反译");
        if (!knownCommand || inputs.isEmpty()) {
            usage();
            System.exit(2);
        }
        if (jarPath != null && mainClass == null) {
            System.err.println("错误：-jar 需要同时用 -主类 指定入口类（例如 -主类 demo.app.Main）");
            System.exit(2);
        }
        if (mainClass != null && jarPath == null) {
            System.err.println("错误：-主类 只能配合 -jar 使用");
            System.exit(2);
        }

        loadKeywords(resolveTable(tableArg));

        if (command.equals("反译")) {
            if (outDir == null) {
                System.err.println("错误：反译命令需要指定输出目录，例如 -d 中文源码");
                System.exit(2);
            }
            reverse(inputs, outDir);
            return;
        }

        LinkedHashMap<Path, Path> collected = collect(inputs);
        List<SourceFile> files = new ArrayList<>();
        Set<String> identifierNames = new HashSet<>();
        for (Map.Entry<Path, Path> e : collected.entrySet()) {
            SourceFile sf = load(e.getKey(), e.getValue());
            files.add(sf);
            for (Token t : sf.tokens) {
                if (t.kind == KIND_IDENTIFIER) {
                    identifierNames.add(t.text);
                }
            }
        }

        int stickyErrors = checkSticky(files, identifierNames);
        int punctuationErrors = checkPunctuation(files);
        int totalErrors = stickyErrors + punctuationErrors;
        if (totalErrors > 0) {
            System.out.println();
            System.out.println("检查未通过：" + totalErrors + " 处错误（CJK001 " + stickyErrors
                    + " 处空格粘连，CJK002 " + punctuationErrors + " 处全角标点）。");
            System.exit(1);
        }
        if (command.equals("检查")) {
            System.out.println("检查通过：" + files.size() + " 个文件（关键字 " + KEYWORDS.size() + " 条）。");
            return;
        }
        if (outDir == null) {
            System.err.println("错误：" + command + "命令需要指定输出目录，例如 -d 输出");
            System.exit(2);
        }
        if (command.equals("转译")) {
            writeTranslated(files, outDir);
            System.out.println("转译完成：" + files.size() + " 个文件 → " + outDir.toAbsolutePath().normalize());
            return;
        }

        int compileErrors = compile(files, outDir, classpath);
        if (compileErrors > 0) {
            System.out.println();
            System.out.println("编译失败：" + compileErrors + " 个错误。");
            System.exit(1);
        }
        System.out.println("编译成功，class 输出目录：" + outDir.toAbsolutePath().normalize());

        if (jarPath != null) {
            if (packageJar(outDir, jarPath, mainClass) != 0) {
                System.out.println();
                System.out.println("打包失败。");
                System.exit(1);
            }
            System.out.println("打包成功，可运行 jar：" + jarPath.toAbsolutePath().normalize());
        }
    }

    static void usage() {
        System.out.println("Cjc —— 中文 Java 源码检查、转译与编译工具（M2）");
        System.out.println("用法：");
        System.out.println("  java 工具\\cjc\\Cjc.java 检查 <文件或目录...> [--表 <关键字表>]");
        System.out.println("  java 工具\\cjc\\Cjc.java 编译 <文件或目录...> -d <输出目录> [-cp <类路径>] [-jar <jar路径> -主类 <全限定类名>]");
        System.out.println("  java 工具\\cjc\\Cjc.java 转译 <文件或目录...> -d <输出目录>");
        System.out.println("  java 工具\\cjc\\Cjc.java 反译 <文件或目录...> -d <输出目录>");
        System.out.println("规则：中文关键字后必须跟空格或标点，否则会与后面的名称粘连成一个标识符。");
        System.out.println("      全角标点会自动规范化为半角；顿号、句号、弯引号等无法映射，报 CJK002。");
    }

    // ------------------------------------------------------------------ 关键字表

    static Path resolveTable(String explicit) {
        if (explicit != null) {
            return Paths.get(explicit);
        }
        List<Path> candidates = new ArrayList<>();
        String home = System.getProperty("cjc.home");
        if (home != null) {
            candidates.add(Paths.get(home, "工具", "cjc", "关键字表.txt"));
        }
        Path cwd = Paths.get(System.getProperty("user.dir"));
        candidates.add(cwd.resolve("工具").resolve("cjc").resolve("关键字表.txt"));
        candidates.add(cwd.resolve("关键字表.txt"));
        for (Path candidate : candidates) {
            if (Files.exists(candidate)) {
                return candidate;
            }
        }
        System.err.println("错误：找不到关键字表，请用 --表 <路径> 指定，或在工程根目录运行 cjc.ps1。");
        System.exit(2);
        return null;
    }

    static void loadKeywords(Path tablePath) throws IOException {
        if (!Files.exists(tablePath)) {
            System.err.println("错误：找不到关键字表 " + tablePath);
            System.exit(2);
        }
        List<String> problems = new ArrayList<>();
        int lineNo = 0;
        for (String raw : Files.readAllLines(tablePath, StandardCharsets.UTF_8)) {
            lineNo++;
            String line = raw.strip();
            if (line.isEmpty() || line.startsWith("#")) {
                continue;
            }
            int eq = line.indexOf('=');
            if (eq <= 0 || eq == line.length() - 1) {
                problems.add("第" + lineNo + "行格式错误，应为「中文=英文」：" + line);
                continue;
            }
            String chinese = line.substring(0, eq).strip();
            String english = line.substring(eq + 1).strip();
            if (KEYWORDS.containsKey(chinese)) {
                problems.add("第" + lineNo + "行中文关键字重复：" + chinese);
                continue;
            }
            // 英文允许重复：多个中文同义词映射到同一个英文关键字（如 公有/公开/公共/公用）
            KEYWORDS.put(chinese, english);
        }
        if (KEYWORDS.isEmpty()) {
            problems.add("关键字表为空");
        }
        // 前缀无关校验：任意两个中文关键字不得存在前缀关系，否则会产生长/短两种切分
        List<String> all = new ArrayList<>(KEYWORDS.keySet());
        for (String longer : all) {
            for (String shorter : all) {
                if (longer.length() > shorter.length() && longer.startsWith(shorter)) {
                    problems.add("前缀冲突：「" + shorter + "」是「" + longer + "」的前缀");
                }
            }
        }
        if (!problems.isEmpty()) {
            for (String problem : problems) {
                System.err.println("关键字表错误：" + problem);
            }
            System.err.println("关键字表校验未通过：" + problems.size() + " 处问题，文件 " + tablePath);
            System.exit(2);
        }
        SORTED_KEYWORDS.clear();
        SORTED_KEYWORDS.addAll(KEYWORDS.keySet());
        // 最长优先，避免短关键字抢先匹配
        SORTED_KEYWORDS.sort((a, b) -> b.length() - a.length());

        CHINESE_BY_ENGLISH.clear();
        for (Map.Entry<String, String> e : KEYWORDS.entrySet()) {
            // 同义词时保留表中第一条为反译规范名
            CHINESE_BY_ENGLISH.putIfAbsent(e.getValue(), e.getKey());
        }
        ENGLISH_KEYWORDS.clear();
        ENGLISH_KEYWORDS.addAll(CHINESE_BY_ENGLISH.keySet());
    }


    // ------------------------------------------------------------------ 文件收集

    static LinkedHashMap<Path, Path> collect(List<String> inputs) throws IOException {
        LinkedHashMap<Path, Path> map = new LinkedHashMap<>();
        Map<Path, Path> owners = new LinkedHashMap<>();
        for (String input : inputs) {
            Path root = Paths.get(input).toAbsolutePath().normalize();
            if (!Files.exists(root)) {
                System.err.println("错误：找不到路径 " + input);
                System.exit(2);
            }
            if (Files.isDirectory(root)) {
                List<Path> list = new ArrayList<>();
                try (Stream<Path> stream = Files.walk(root)) {
                    stream.filter(Files::isRegularFile)
                            .filter(p -> p.getFileName().toString().endsWith(".java"))
                            .forEach(list::add);
                }
                list.sort(Comparator.comparing(Path::toString));
                for (Path p : list) {
                    addSource(map, owners, p, root.relativize(p));
                }
            } else {
                addSource(map, owners, root, root.getFileName());
            }
        }
        if (map.isEmpty()) {
            System.err.println("错误：没有找到 .java 文件");
            System.exit(2);
        }
        return map;
    }

    /**
     * 转译与编译都按「相对源根的路径」输出，因此不同源根下出现同名相对路径时必须报错，
     * 否则后写入的文件会静默覆盖前一个。
     */
    static void addSource(LinkedHashMap<Path, Path> map, Map<Path, Path> owners,
                          Path file, Path relative) {
        Path prev = owners.putIfAbsent(relative, file);
        if (prev != null && !prev.equals(file)) {
            System.err.println("错误：不同源根目录下存在相同的相对路径「" + relative + "」：");
            System.err.println("      " + prev);
            System.err.println("      " + file);
            System.err.println("  输出按相对路径落盘，无法同时保留两份，请调整目录结构或分开执行。");
            System.exit(2);
        }
        map.putIfAbsent(file, relative);
    }

    static String read(Path path) throws IOException {
        String text = Files.readString(path, StandardCharsets.UTF_8);
        if (!text.isEmpty() && text.charAt(0) == '\uFEFF') {
            text = text.substring(1);
        }
        return text;
    }

    static SourceFile load(Path path, Path relative) throws IOException {
        SourceFile sf = new SourceFile(path, relative, read(path));
        sf.tokens = scan(sf.original, false);
        sf.origLineStarts = lineStarts(sf.original);
        sf.translated = translate(sf);
        return sf;
    }

    // ------------------------------------------------------------------ 词法扫描

    /**
     * @param english true 表示反译模式：把英文关键字识别为 KIND_EN_KEYWORD；
     *                false 表示正常模式：把中文关键字识别为 KIND_KEYWORD。
     */
    static List<Token> scan(String source, boolean english) {
        List<Token> tokens = new ArrayList<>();
        int n = source.length();
        int i = 0;
        while (i < n) {
            int cp = source.codePointAt(i);
            int width = Character.charCount(cp);

            // 全角空格：javac 会报「非法字符」，这里统一转成半角空格
            if (cp == 0x3000) {
                tokens.add(new Token(KIND_PUNCT, i, i + 1, " "));
                i++;
                continue;
            }
            if (Character.isWhitespace(cp)) {
                i += width;
                continue;
            }
            // 行注释
            if (cp == '/' && i + 1 < n && source.charAt(i + 1) == '/') {
                int j = i + 2;
                while (j < n && source.charAt(j) != '\n' && source.charAt(j) != '\r') {
                    j++;
                }
                i = j;
                continue;
            }
            // 块注释
            if (cp == '/' && i + 1 < n && source.charAt(i + 1) == '*') {
                int j = source.indexOf("*/", i + 2);
                i = (j < 0) ? n : j + 2;
                continue;
            }
            // 文本块
            if (cp == '"' && source.startsWith("\"\"\"", i)) {
                int j = i + 3;
                while (j < n) {
                    int k = source.indexOf("\"\"\"", j);
                    if (k < 0) {
                        j = n;
                        break;
                    }
                    if (k > 0 && source.charAt(k - 1) == '\\') {
                        j = k + 1;
                        continue;
                    }
                    j = k + 3;
                    break;
                }
                tokens.add(new Token(KIND_OTHER, i, j, null));
                i = j;
                continue;
            }
            // 字符串 / 字符字面量
            if (cp == '"' || cp == '\'') {
                int j = i + 1;
                while (j < n) {
                    char ch = source.charAt(j);
                    if (ch == '\\') {
                        j += 2;
                        continue;
                    }
                    if (ch == cp || ch == '\n') {
                        j++;
                        break;
                    }
                    j++;
                }
                if (j > n) {
                    j = n;
                }
                tokens.add(new Token(KIND_OTHER, i, j, null));
                i = j;
                continue;
            }
            // 标识符（含中文标识符）
            if (Character.isJavaIdentifierStart(cp)) {
                int start = i;
                i += width;
                while (i < n) {
                    int next = source.codePointAt(i);
                    if (!Character.isJavaIdentifierPart(next)) {
                        break;
                    }
                    i += Character.charCount(next);
                }
                String text = source.substring(start, i);
                int kind;
                if (english) {
                    kind = ENGLISH_KEYWORDS.contains(text) ? KIND_EN_KEYWORD : KIND_IDENTIFIER;
                } else {
                    kind = KEYWORDS.containsKey(text) ? KIND_KEYWORD : KIND_IDENTIFIER;
                }
                tokens.add(new Token(kind, start, i, text));
                continue;
            }
            // 数字字面量（整体跳过，不参与关键字判定）
            if (Character.isDigit(cp) || (cp == '.' && i + 1 < n && Character.isDigit(source.charAt(i + 1)))) {
                int start = i;
                i += width;
                while (i < n) {
                    int next = source.codePointAt(i);
                    if (Character.isJavaIdentifierPart(next) || next == '.') {
                        i += Character.charCount(next);
                        continue;
                    }
                    if ((next == '+' || next == '-') && i > start) {
                        int prev = source.codePointBefore(i);
                        if (prev == 'e' || prev == 'E') {
                            i++;
                            continue;
                        }
                    }
                    break;
                }
                tokens.add(new Token(KIND_OTHER, start, i, null));
                continue;
            }
            // 全角 ASCII 标点（U+FF01..U+FF5E）：平移 0xFEE0 得到半角
            if (cp >= 0xFF01 && cp <= 0xFF5E) {
                tokens.add(new Token(KIND_PUNCT, i, i + 1, String.valueOf((char) (cp - 0xFEE0))));
                i++;
                continue;
            }
            // 无法映射到半角的 CJK 标点：保留原文，报 CJK002
            if (CJK_PUNCTUATION.contains(cp)) {
                tokens.add(new Token(KIND_BAD_PUNCT, i, i + width, new String(Character.toChars(cp))));
                i += width;
                continue;
            }
            tokens.add(new Token(KIND_OTHER, i, i + width, null));
            i += width;
        }
        return tokens;
    }

    // ------------------------------------------------------------------ 空格硬约束检查

    static int checkSticky(List<SourceFile> files, Set<String> identifierNames) {
        int count = 0;
        for (SourceFile sf : files) {
            for (Token t : sf.tokens) {
                if (t.kind != KIND_IDENTIFIER) {
                    continue;
                }
                String keyword = null;
                for (String k : SORTED_KEYWORDS) {
                    if (t.text.length() > k.length() && t.text.startsWith(k)) {
                        keyword = k;
                        break;
                    }
                }
                if (keyword == null) {
                    continue;
                }
                String rest = t.text.substring(keyword.length());
                // 判定：剩余部分是一个已知符号（标识符），或者是一个多字关键字。
                // 这样能抓住「新建列表」「类用户」「返回结果」「返回真」这类真实错误，
                // 又不会因为「当前值」「无效」「字符串」这类正常命名而误报。
                boolean hit = identifierNames.contains(rest)
                        || (keyword.length() >= 2 && KEYWORDS.containsKey(rest));
                if (!hit) {
                    continue;
                }
                count++;
                reportSticky(sf, t, keyword, rest);
            }
        }
        return count;
    }

    static void reportSticky(SourceFile sf, Token token, String keyword, String rest) {
        int lineIndex = lineOf(sf.origLineStarts, token.start);
        int line = lineIndex + 1;
        int tokenCol = token.start - sf.origLineStarts[lineIndex];
        int gapCol = tokenCol + keyword.length();
        String lineText = lineText(sf.original, sf.origLineStarts, line);

        System.err.println();
        System.err.println("错误 CJK001  第" + line + "行 第" + (gapCol + 1) + "列");
        System.err.println("  中文关键字「" + keyword + "」后缺少空格，与名称「" + rest
                + "」粘连，被整体识别为标识符「" + token.text + "」。");
        System.err.println("    " + String.format("%4d", line) + " | " + lineText);
        System.err.println("         | " + spaces(gapCol) + "^ 这里缺一个空格");
        String fixedLine = lineText.substring(0, gapCol) + " " + lineText.substring(gapCol);
        System.err.println("  修正：" + fixedLine.trim());
    }

    // ------------------------------------------------------------------ 全角标点检查

    static int checkPunctuation(List<SourceFile> files) {
        int count = 0;
        for (SourceFile sf : files) {
            for (Token t : sf.tokens) {
                if (t.kind != KIND_BAD_PUNCT) {
                    continue;
                }
                count++;
                int lineIndex = lineOf(sf.origLineStarts, t.start);
                int line = lineIndex + 1;
                int col = t.start - sf.origLineStarts[lineIndex];
                String lineText = lineText(sf.original, sf.origLineStarts, line);
                System.err.println();
                System.err.println("错误 CJK002  第" + line + "行 第" + (col + 1) + "列");
                System.err.println("  不支持的全角标点「" + t.text + "」，请改用半角标点"
                        + "（, . ? : ; \" ' ( ) 等）。");
                System.err.println("    " + String.format("%4d", line) + " | " + lineText);
                System.err.println("         | " + spaces(col) + "^");
            }
        }
        return count;
    }

    // ------------------------------------------------------------------ 翻译

    static String translate(SourceFile sf) {
        StringBuilder sb = new StringBuilder(sf.original.length() * 2);
        List<int[]> pending = new ArrayList<>(); // {origStart, origLen, genStart, genLen}
        int cursor = 0;
        for (Token t : sf.tokens) {
            if (t.start > cursor) {
                sb.append(sf.original, cursor, t.start);
            }
            if (t.kind == KIND_KEYWORD) {
                String english = KEYWORDS.get(t.text);
                int genStart = sb.length();
                sb.append(english);
                int pad = t.text.length() - english.length();
                if (pad > 0) {
                    sb.append(" ".repeat(pad));
                }
                pending.add(new int[]{t.start, t.text.length(), genStart, Math.max(t.text.length(), english.length())});
            } else if (t.kind == KIND_PUNCT) {
                // 标点规范化是 1 字符换 1 字符，不影响列号
                sb.append(t.text);
            } else {
                sb.append(sf.original, t.start, t.end);
            }
            cursor = t.end;
        }
        if (cursor < sf.original.length()) {
            sb.append(sf.original, cursor, sf.original.length());
        }
        String translated = sb.toString();

        int[] genLineStarts = lineStarts(translated);
        for (int[] r : pending) {
            int genLine = lineOf(genLineStarts, r[2]);
            int genCol = r[2] - genLineStarts[genLine];
            int origLine = lineOf(sf.origLineStarts, r[0]);
            int origCol = r[0] - sf.origLineStarts[origLine];
            sf.replacements.add(new Replacement(genLine, genCol, origCol, r[1], r[3]));
        }
        return translated;
    }

    // ------------------------------------------------------------------ 转译落盘 / 反译 / 打包

    /** 转译结果按相对源根的路径写入输出目录，供构建工具（Maven 插件）接管后续 javac。 */
    static void writeTranslated(List<SourceFile> files, Path outDir) throws IOException {
        for (SourceFile sf : files) {
            Path target = outDir.resolve(sf.relative);
            Path parent = target.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            Files.writeString(target, sf.translated, StandardCharsets.UTF_8);
        }
    }

    static void reverse(List<String> inputs, Path outDir) throws IOException {
        LinkedHashMap<Path, Path> collected = collect(inputs);
        for (Map.Entry<Path, Path> e : collected.entrySet()) {
            String chinese = reverseTranslate(read(e.getKey()));
            Path target = outDir.resolve(e.getValue());
            Path parent = target.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            Files.writeString(target, chinese, StandardCharsets.UTF_8);
        }
        System.out.println("反译完成：" + collected.size() + " 个文件 → "
                + outDir.toAbsolutePath().normalize());
    }

    /**
     * 英文关键字 → 中文关键字。原关键字与后一个记号之间必然已有分隔符，
     * 因此替换后不会产生新的粘连，无需补空格。
     */
    static String reverseTranslate(String source) {
        List<Token> tokens = scan(source, true);
        StringBuilder sb = new StringBuilder(source.length());
        int cursor = 0;
        for (Token t : tokens) {
            if (t.start > cursor) {
                sb.append(source, cursor, t.start);
            }
            if (t.kind == KIND_EN_KEYWORD) {
                sb.append(CHINESE_BY_ENGLISH.get(t.text));
            } else {
                sb.append(source, t.start, t.end);
            }
            cursor = t.end;
        }
        if (cursor < source.length()) {
            sb.append(source, cursor, source.length());
        }
        return sb.toString();
    }

    static int packageJar(Path outDir, Path jarPath, String mainClass) throws IOException {
        Path target = jarPath.toAbsolutePath().normalize();
        Path parent = target.getParent();
        if (parent != null) {
            Files.createDirectories(parent);
        }
        java.util.spi.ToolProvider jar = java.util.spi.ToolProvider.findFirst("jar").orElse(null);
        if (jar == null) {
            System.err.println("错误：当前 JDK 不提供 jar 工具，无法打包");
            return 1;
        }
        return jar.run(System.out, System.err,
                "--create",
                "--file", target.toString(),
                "--main-class", mainClass,
                "-C", outDir.toAbsolutePath().normalize().toString(), ".");
    }

    // ------------------------------------------------------------------ 编译与诊断回映射

    static int compile(List<SourceFile> files, Path outDir, String classpath) throws IOException {
        Path tempDir = Files.createTempDirectory("cjc-");
        Map<Path, SourceFile> byTempPath = new LinkedHashMap<>();
        try {
            for (SourceFile sf : files) {
                Path temp = tempDir.resolve(sf.relative);
                Files.createDirectories(temp.getParent());
                Files.writeString(temp, sf.translated, StandardCharsets.UTF_8);
                sf.tempPath = temp;
                byTempPath.put(temp.toAbsolutePath().normalize(), sf);
            }
            Files.createDirectories(outDir);

            JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
            if (compiler == null) {
                System.err.println("错误：当前运行环境没有 javac 编译器（需要 JDK，而不是 JRE）");
                return 1;
            }
            DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
            int errorCount;
            try (StandardJavaFileManager fileManager =
                         compiler.getStandardFileManager(diagnostics, Locale.CHINA, StandardCharsets.UTF_8)) {
                List<String> options = new ArrayList<>(List.of(
                        "-d", outDir.toAbsolutePath().normalize().toString(),
                        "-encoding", "UTF-8",
                        "-proc:none"));
                if (classpath != null) {
                    options.add("-classpath");
                    options.add(classpath);
                }
                Iterable<? extends JavaFileObject> units = fileManager.getJavaFileObjectsFromPaths(
                        files.stream().map(f -> f.tempPath).collect(Collectors.toList()));
                compiler.getTask(null, fileManager, diagnostics, options, null, units).call();
            }
            errorCount = printDiagnostics(diagnostics, byTempPath);
            return errorCount;
        } finally {
            deleteRecursively(tempDir);
        }
    }

    static int printDiagnostics(DiagnosticCollector<JavaFileObject> collector,
                                Map<Path, SourceFile> byTempPath) {
        int errors = 0;
        for (Diagnostic<? extends JavaFileObject> d : collector.getDiagnostics()) {
            if (d.getKind() == Diagnostic.Kind.NOTE) {
                continue;
            }
            String label = switch (d.getKind()) {
                case ERROR -> "错误";
                case WARNING, MANDATORY_WARNING -> "警告";
                default -> "提示";
            };
            SourceFile sf = resolveSource(d, byTempPath);
            String message = d.getMessage(Locale.CHINA);
            if (sf == null || d.getLineNumber() <= 0) {
                System.err.println(label + "：" + message);
            } else {
                int line = (int) d.getLineNumber();
                int col = remapColumn(sf, line, (int) d.getColumnNumber());
                System.err.println();
                System.err.println(label + "：第" + line + "行 第" + col + "列  " + message);
                System.err.println("    " + String.format("%4d", line) + " | "
                        + lineText(sf.original, sf.origLineStarts, line));
                if (col > 0) {
                    System.err.println("         | " + spaces(col - 1) + "^");
                }
            }
            if (d.getKind() == Diagnostic.Kind.ERROR) {
                errors++;
            }
        }
        return errors;
    }

    static SourceFile resolveSource(Diagnostic<? extends JavaFileObject> d,
                                    Map<Path, SourceFile> byTempPath) {
        JavaFileObject source = d.getSource();
        if (source == null) {
            return null;
        }
        try {
            Path p = Paths.get(source.toUri()).toAbsolutePath().normalize();
            return byTempPath.get(p);
        } catch (RuntimeException ex) {
            return null;
        }
    }

    /**
     * 把译文中的列号还原成中文源码中的列号。
     * 关键字替换会改变同一行的字符数，替换点之后的列需要平移。
     */
    static int remapColumn(SourceFile sf, int line, int generatedColumn) {
        if (generatedColumn <= 0) {
            return generatedColumn;
        }
        int genCol = generatedColumn - 1;
        Replacement hit = null;
        for (Replacement r : sf.replacements) {
            if (r.line == line - 1 && r.genCol <= genCol) {
                hit = r;
            }
        }
        if (hit == null) {
            return generatedColumn;
        }
        int inside = genCol - hit.genCol;
        if (inside < hit.genLen) {
            return hit.origCol + 1;
        }
        return hit.origCol + hit.origLen + (inside - hit.genLen) + 1;
    }

    // ------------------------------------------------------------------ 工具方法

    static int[] lineStarts(String text) {
        List<Integer> starts = new ArrayList<>();
        starts.add(0);
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '\n') {
                starts.add(i + 1);
            } else if (c == '\r' && !(i + 1 < text.length() && text.charAt(i + 1) == '\n')) {
                starts.add(i + 1);
            }
        }
        int[] result = new int[starts.size()];
        for (int i = 0; i < result.length; i++) {
            result[i] = starts.get(i);
        }
        return result;
    }

    static int lineOf(int[] starts, int offset) {
        int lo = 0;
        int hi = starts.length - 1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (starts[mid] <= offset) {
                lo = mid + 1;
            } else {
                hi = mid - 1;
            }
        }
        return Math.max(0, lo - 1);
    }

    static String lineText(String text, int[] lineStarts, int line) {
        int index = line - 1;
        if (index < 0 || index >= lineStarts.length) {
            return "";
        }
        int start = lineStarts[index];
        int end = (index + 1 < lineStarts.length) ? lineStarts[index + 1] : text.length();
        return text.substring(start, end).replace("\r", "").replace("\n", "");
    }

    static String spaces(int count) {
        return " ".repeat(Math.max(0, count));
    }

    static void deleteRecursively(Path root) throws IOException {
        if (!Files.exists(root)) {
            return;
        }
        try (Stream<Path> stream = Files.walk(root)) {
            List<Path> paths = stream.sorted(Comparator.reverseOrder()).collect(Collectors.toList());
            for (Path p : paths) {
                Files.deleteIfExists(p);
            }
        }
    }

    // ------------------------------------------------------------------ 数据结构

    static final class Token {
        final int kind;
        final int start;
        final int end;
        final String text;

        Token(int kind, int start, int end, String text) {
            this.kind = kind;
            this.start = start;
            this.end = end;
            this.text = text;
        }
    }

    static final class Replacement {
        final int line;
        final int genCol;
        final int origCol;
        final int origLen;
        final int genLen;

        Replacement(int line, int genCol, int origCol, int origLen, int genLen) {
            this.line = line;
            this.genCol = genCol;
            this.origCol = origCol;
            this.origLen = origLen;
            this.genLen = genLen;
        }
    }

    static final class SourceFile {
        final Path path;
        final Path relative;
        final String original;
        final List<Replacement> replacements = new ArrayList<>();
        List<Token> tokens;
        int[] origLineStarts;
        String translated;
        Path tempPath;

        SourceFile(Path path, Path relative, String original) {
            this.path = path;
            this.relative = relative;
            this.original = original;
        }
    }
}
